const items = document.querySelectorAll('.slider img');
const itemCount = items.length;
const nextItem = document.querySelector('.next');
const previousItem = document.querySelector('.previous');
let count = 0;

function showNextItem() {
  items[count].classList.remove('active');
  count = (count < itemCount - 1) ? count + 1 : 0;
  items[count].classList.add('active');
}

function showPreviousItem() {
  items[count].classList.remove('active');
  count = (count > 0) ? count - 1 : itemCount - 1;
  items[count].classList.add('active');
}

function keyPress(e) {
  if (e.keyCode === 37) {
    showPreviousItem();
  } else if (e.keyCode === 39) {
    showNextItem();
  }
}

nextItem.addEventListener('click', showNextItem);
previousItem.addEventListener('click', showPreviousItem);
document.addEventListener('keydown', keyPress);

// Auto-advance slider every 3 seconds
setInterval(showNextItem, 3000);